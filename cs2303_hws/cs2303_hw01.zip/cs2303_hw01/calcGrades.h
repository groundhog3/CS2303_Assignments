#ifndef CALC_GRADES_H  
#define CALC_GRADES_H

void calcGrades(int num_grades, int all_grades[]);

#endif 
